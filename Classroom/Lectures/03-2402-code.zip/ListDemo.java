import java.util.List;        // List Interface
import java.util.ArrayList;   // Array-based implementation of the List Interface
import java.util.LinkedList;  // Node-based implementation of the List Interface
import java.util.Collections; // The class of helpful methods that operate on or return collections
/* only import classes that you need, don't do   
import java.util.*; 
You might run into name conflicts. */

/* In Java, every application begins with a class definition.
   A class name should always start with an uppercase first letter.
   The name of the java file must match the class name.
*/

public class ListDemo {
  /* The main method is the entry point for your application and will 
     subsequently invoke all the other methods required by your program.
     Any code inside the main() method will be executed.
     The main method accepts a single argument: an array of elements of 
     type String. This array will hold command-line arguments passed to 
     your application during runtime.*/
  public static void main(String[] args) { 
    int n = 10;  //size of the list 
    if (args.length == 1) {
      n = Integer.parseInt(args[0]); // command-line argument specifies the size of the list
    }

    String[] names = {"Margo", "David", "Maryam", "Amy", "Ray", "Benedict"};

    //create a new list that will contain strings
    ///ds is a variable of type List and you only can do operations on it that are supported by the list interface
    ///if you want to change implementation - it is easy to do.
    List<String> ds = new ArrayList<>(); 

    //append the specified element to the end of this list ds.
    for (String s : names) {
      ds.add(s);
      System.out.println(ds);  //to see how elements were added to the list
    }
    //System.out.println(ds);
    

/*

    //add to the front of the list - this way you will reverse the order of the list.
    for (String s : names) {
      ds.add(0, s);
    }
    System.out.println(ds);

    //add to a specific position in the list. Shift the element currently at that position (if any) and any subsequent elements to the right
    ds.add(3, "Nick");
    System.out.println(ds);

    // //iterate over the elements of the list
    // for (String s: ds) {
    //   System.out.println(s);
    //   //System.out.print(s + " ");
    // }

    //remove the element at the specified position in this list. Shift any subsequent elements to the left.
    ds.remove(2);
    System.out.println(ds);

    //replace the element at the specified position in this list with the specified element.
    ds.set(2, "Misha");
    System.out.println(ds);


    // Let's look into performance and set up a timer. 
    //   The variables below are used to measure time taken by a specific process 
    long start, stop; 
    double elapsed;

    //create a new list of integers
    List<Integer> ds2 = new ArrayList<>();
    //List<Integer> ds2 = new LinkedList<>();

    System.out.print("Adding " + n + " values..."); // notice, not println
    System.out.flush(); //Flushes this output stream and forces any buffered output bytes to be written out. 
    start = System.nanoTime();  //returns the current time in nanoseconds (1 second = 10^9 nanoseconds)
    //add n integers to the end of the list ds2 (try big values of n: ~100,000,000)
    for (int i = 0; i < n; i++) {
      ds2.add(2*i);  
    }
    stop = System.nanoTime();
    elapsed = ((double)stop-start)*1e-9; // the time (in seconds) it took to add n integers to the list
    System.out.println("done (" + elapsed + "s)");
    ///adding 100 million elements in 3 seconds is quite fast.



    ds2.clear(); //empty the list
    System.out.print("Adding " + n + " values at the front...");
    System.out.flush();
    start = System.nanoTime();
    //add n integers to the front of the list ds2 (try smaller values of n: ~100,000)
    for (int i = 0; i < n; i++) {
      ds2.add(0, 2*i);  //adding even integers (our elements) to the front of the list
    }
    stop = System.nanoTime();
    elapsed = ((double)stop-start)*1e-9;
    System.out.println("done (" + elapsed + "s)");
    ///adding 1 million elements to the front of the list takes ~58 seconds on my laptop on a good day



    System.out.print("Using " + 2*n + " calls to contains()...");
    System.out.flush();
    start = System.nanoTime();
    for (int i = 0; i < 2*n; i++) {
      ds2.contains(i);  //checking if the list contains element i
    }
    stop = System.nanoTime();
    elapsed = ((double)stop-start)*1e-9;
    System.out.println("done (" + elapsed + "s)");
    ///checking 200000 elements took ~20 seconds on my device




    List<Integer> ds3 = new ArrayList<>();
    for (int i = 0; i < n; i++) {
      ds3.add(2*i);  
    }
    System.out.println("We created a Sorted List of even integers: {0, 2, 4, ..., "+ 2*n + "}");
    System.out.print("Using " + 2*n + " calls to binarySearch()...");
    System.out.flush();
    start = System.nanoTime();
    for (int i = 0; i < 2*n; i++) {
      Collections.binarySearch(ds3, i);  //checking if the list contains element i
    }
    stop = System.nanoTime();
    elapsed = ((double)stop-start)*1e-9; // the time (in seconds) it took to add n integers to the list
    System.out.println("done (" + elapsed + "s)");
   ///searching for 200000 elements in a sorted list is super fast

*/
  }
}
