import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;


public class SetDemo {
  public static void main(String[] args) {
    int n = 10;
    if (args.length == 1) {
      n = Integer.parseInt(args[0]);
    }

    String[] names = {"Margo", "David", "Maryam", "Amy", "Ray", "Benedict"};

    Set<String> ds = new HashSet<>();    //Unsorted set
    //Set<String> ds = new TreeSet<>();    //Sorted set (for strings - lexicografic comparison; uppercase comes before lowercase)
    for (String s : names) {
      ds.add(s);
    }
    System.out.println(ds); //you cannot rely on the order of elements in a set

    ds.add("Misha");
    System.out.println(ds);
/*
    ds.remove("Maryam");
    System.out.println(ds);

    ds.add("alex"); //uppercase comes before lowercase (for SortedSet)
    System.out.println(ds);


    System.out.println("contains(Amy) = " + ds.contains("Amy"));
    System.out.println("contains(Jason) = " + ds.contains("Jason"));

    ////System.exit(0); //indicates successful termination

    long start, stop;
    double elapsed;
    Set<Integer> ds2 = new HashSet<>();

    start = System.nanoTime();
    System.out.print("Adding " + n + " elements to HashSet ...");
    System.out.flush();
    for (int i = 0; i < n; i++) {
      ds2.add(2*i);
    }
    stop=System.nanoTime();
    elapsed = ((double)(stop-start))*1e-9;
    System.out.println("done (" + elapsed + "s)");

    start = System.nanoTime();
    System.out.print("Searching " + 2*n + " elements...");
    System.out.flush();
    for (int i = 0; i < 2*n; i++) {
      ds2.contains(i);
    }
    stop=System.nanoTime();
    elapsed = ((double)(stop-start))*1e-9;
    System.out.println("done (" + elapsed + "s)");

    ds2 = new TreeSet<>();
    start = System.nanoTime();
    System.out.print("Adding " + n + " elements to TreeSet ...");
    System.out.flush();
    for (int i = 0; i < n; i++) {
      ds2.add(2*i);
    }
    stop=System.nanoTime();
    elapsed = ((double)(stop-start))*1e-9;
    System.out.println("done (" + elapsed + "s)");

    start = System.nanoTime();
    System.out.print("Searching " + 2*n + " elements...");
    System.out.flush();
    for (int i = 0; i < 2*n; i++) {
      ds2.contains(i);
    }
    stop=System.nanoTime();
    elapsed = ((double)(stop-start))*1e-9;
    System.out.println("done (" + elapsed + "s)");
    */
  }
}
