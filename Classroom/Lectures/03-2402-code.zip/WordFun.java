import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;
import java.util.*;

public class WordFun {
	//This method opens a file and parses it into words. 
	//It returns the content of the file as a list of strings.
	public static List<String> slurp(BufferedReader r) throws IOException {
		StringBuffer sb = new StringBuffer();
    char[] buf = new char[1024];
    int c = 0;
		while ((c = r.read(buf)) > 0) {
			sb.append(String.valueOf(buf, 0, c).toLowerCase());
		}
		return Arrays.asList(sb.toString().split("\\W+"));  //split at word boundaries
	}

	static String reverse(String s) {
		return new StringBuffer(s).reverse().toString();
	}

  /**
   * Get the first n elements from a collection
   */
  static <T> List<T> first_n(Collection<T> c, int n) {
		int i = 0;
		Iterator<T> it = c.iterator();
		List<T> ell = new ArrayList<T>();
		while (it.hasNext() && i++ < n)
	    ell.add(it.next());
		return ell;
  }

	/**
     * Playground
	 * @param r the reader to read from
	 * @param w the writer to write to
	 * @throws IOException
	 */
	public static void doIt(BufferedReader r, PrintWriter w) throws IOException {
    // gulp down the file and splice it into a list of words
		List<String> wordList = slurp(r);

		System.out.println(first_n(wordList, 20));

    // count the number of words
		System.out.println("# of words = " + wordList.size());

/*
    // count the number of distinct words (vocabulary)
		Set<String> wordSet = new HashSet<>();
		for (String s : wordList) {
			wordSet.add(s);
		}
		// or you can use the operation below which is a bit faster
		//wordSet.addAll(wordList);

		System.out.println("# of distinct words (vocabular size)= " + wordSet.size());
    // a random sample of 50 words
		Collections.shuffle(wordList); //this method randomly permutes the elements
		System.out.println(first_n(wordList, 50));

	// find all the ananyms (ananym of a string is the reverse of this string)
		System.out.println("All the ananyms in the collection");
		for (String s: wordSet) {
			if (wordSet.contains(reverse(s))) {
				System.out.println(s);
			}
		}
		System.out.println("All the ananyms in the collection------------------DONE");

    // make a dictionary (a sorted list of distinct words)
		SortedSet<String> sortedWordSet = new TreeSet<>();
		for (String s : wordSet) {
			sortedWordSet.add(s);
		}
		System.out.println(first_n(sortedWordSet, 20)); //let's print the first 20 distinct words in sorted order 

	// lookup a specific word
		SortedSet<String> ts1 = sortedWordSet.tailSet("a");  //every string greater than "a"
		System.out.println(first_n(ts1, 20));
		SortedSet<String> ts2 = sortedWordSet.tailSet("fox"); //every string greater than "fox"
		System.out.println(first_n(ts2, 20));

    // find the most frequently occurring word
		Map<String,Integer> freq = new HashMap<>(); //Map with keys Strings and values Integers
		for (String s : wordList) {
			if (freq.containsKey(s)) { //containsKey() returns true if this map contains a mapping for the specified key.
				freq.put(s, freq.get(s) + 1); //get() returns the value to which the specified key is mapped
			} else {
				freq.put(s, 1);  // put() Associates the specified value with the specified key in this map. If the map previously contained a mapping for the key, the old value is replaced.
			}
		}
        // now we need to find the most frequent word in our Map 
		int besti = 0;
		String bests = "";
		for (String s : freq.keySet()) { //keySet() returns a Set view of the keys contained in this map
			if (freq.get(s) > besti) {   //get() returns the value to which the specified key is mapped
				besti = freq.get(s);
				bests = s;
			}
		}
		System.out.println(bests + " (" + besti + ")");

    // find the top k most frequently occurring words
    // we will do this by copying our map (key-value pairs) into an array, which we will sort by values in decreasing order.
		List<Map.Entry<String,Integer>> entryList = new ArrayList<>(); //A map entry (key-value pair).
        //iterate through key-value entries
		for (Map.Entry<String,Integer> me : freq.entrySet()) { //entrySet() returns a Set view of the mappings contained in this map.
				entryList.add(me);
		}
        //Collections.sort(entryList); //this will generate an error, because it is not clear how to compare these key-value pairs
		Collections.sort(entryList, new Comparator<Map.Entry<String,Integer>>() { // anonymous class that defines comparison rules.
			public int compare(Map.Entry<String,Integer> a, Map.Entry<String,Integer> b) {
                //return negative value if a should come before b; positive - if b is before a; and 0 if a equals to b. 
				return b.getValue() -  a.getValue(); //getValue() is a method of Map.Entry interface that returns the value corresponding to this entry. getKey() returns the key.
            }
		});
		System.out.println(first_n(entryList, 20));
		*/
	}

	/**
	 * The driver.  Open a BufferedReader and a PrintWriter, either from System.in
	 * and System.out or from filenames specified on the command line, then call doIt.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			BufferedReader r;
			PrintWriter w;
			if (args.length == 0) {
				r = new BufferedReader(new InputStreamReader(System.in));
				w = new PrintWriter(System.out);
			} else if (args.length == 1) {
				r = new BufferedReader(new FileReader(args[0]));
				w = new PrintWriter(System.out);
			} else {
				r = new BufferedReader(new FileReader(args[0]));
				w = new PrintWriter(new FileWriter(args[1]));
			}
			long start = System.nanoTime();
			doIt(r, w);
			w.flush();
			long stop = System.nanoTime();
			System.out.println("Execution time: " + 1e-9 * (stop-start));
		} catch (IOException e) {
			System.err.println(e);
			System.exit(-1);
		}
	}
}
