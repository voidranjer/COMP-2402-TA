package ods;

public interface Integerizer<T> {
	public int intValue(T x);
}
