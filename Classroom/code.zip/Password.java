//declare a class
public class Password{
  //declare attributes
  private String password;
  private String retypedpassword;

  //setters and getters
  Password(String x){
    this.password = x;
  }
  public String getpassword()
  {
    return this.password;
  }
  
  //Override the predefined hashCode function
  @Override
  public int hashCode(){
    return (int) password.hashCode();
  }
  //Override the predefined equals function
  @Override
  public boolean equals(Object x){
    if (x == null)
      return false;
    Password y = (Password) x;
    return y.getpassword() == this.getpassword() ;
  }

}