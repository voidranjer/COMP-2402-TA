//declare a separate class to compare two objects
class Hashes{
 
  public static void main(String args[])
  {
    //declare two objects
    Password p1 = new Password("ABC");
    Password p2 = new Password("ABC");
    //compare and print
    System.out.println("Hash for password 1: ");
    System.out.println(p1.hashCode());
    System.out.println("Hash for password 2: ");
    System.out.println(p2.hashCode());

    System.out.println("Equal? ");
    System.out.println(p1.equals(p2));
  } 
}